# frcit_gen_ai_sttp
Gen AI apps using OPEN AI

#Steps 1- first login to github.com and copy the repository link

https://github.com/utkarshminds/frcit_gen_ai_sttp.git

#Step 2 - open vs code and click on clone git repository
#Step 3- select a folder on local PC where the repository will be cloned
#Step 4- click on open repository
#Step 5 - click ÿes i trust the authors


#Create virtual environment
#Virtual environment - container for your project
# Step 1 -  pip install virtualenv (to install the library)
#python -m venv NAME_OF_THE_VIRTUAL_ENVIRONMENT
# Step 2-  python -m venv myenv
# Step 3-  myenv/Scripts/activate (activate the environment)
#deactivate (come out the environment)
# Step 4-  pip install openai (install openai package)
# Step 5-  pip install streamlit (install streamlit package)
# Step 6 - pip install pipreqs (install pipreqs)
# Step 7 - pipreqs --ignore myenv (create requirements.txt)
# Step 8 - open .gitignore and type inside myenv/ and then save the file
# Step 9 - type git status in terminal
# Step 10 - type git branch pranav (git branch BRANCH_NAME)
# Step 11 - type git checkout pranav (git checkout BRANCH_NAME)
# Step 12 - type git status (Verify if you are in your branch)
# Step 13 - commit the files to remote repo
'''
If any problem in creating virtual env then

Run PowerShell as Administrator:
Right-click on the PowerShell icon and select "Run as administrator".
      Then, execute the following command:
Set-ExecutionPolicy RemoteSigned
Select "ÿes"
'''

# step 14 - write a basic program in main.py
# step 15 - go to https://streamlit.io/cloud
